<?php get_header() ?>

<main>
    <section class="container">
        <h2>Erro 404</h2>
    </section>
</main>

<?php get_footer() ?>